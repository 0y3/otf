<?= $this->extend('main/layout') ?>

<?= $this->section('content') ?>

<?= $this->endsection() ?>