<!-- Modal -->
<div class="modal fade" id="addupMenuModal" tabindex="-1" aria-labelledby="staticAddupMenuLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable dropdown-menu-right shadow-sm border-0">
    <div class="modal-content">
        <!-- <div class="modal-header">
            <h5 class="modal-title" id="staticBackdropLabel">Modal title</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>  -->
        <div class="modal-body addupmenu-modal-body">
            <div class="d-flex justify-content-center">
                <div class="spinner-border" role="status">
                    <!-- <span class="visually-hidden">Loading...</span> -->
                </div>
            </div>
        </div>
    </div>
  </div>
</div>
